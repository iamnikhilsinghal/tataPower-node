const { simpleInterest } = require("custom-package-demo2025");
console.log(simpleInterest(2000, 10, 2));
