// app.js
const logger = require("./logger");

logger.info("This is an info message");
logger.error("This is an error message");
