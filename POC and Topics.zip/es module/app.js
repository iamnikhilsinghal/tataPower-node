// const { add } = require("./math");              // js modules
import { add } from "./math.js";             // es module

const result = add(5, 7);

console.log("result", result);
